# PLIEGO — Flyway SQL v1.0

Materialización ejecutable de las baselines de PLIEGO para **PostgreSQL 18.x**.

## Aplicación

Flyway debe aplicar `database/migration/V001...V019` en orden sobre una base vacía.

`V010__seed_initial_admin.sql` requiere los placeholders:

- `PLIEGO_ADMIN_EMAIL`
- `PLIEGO_ADMIN_PASSWORD_HASH`

Sus valores deben venir del entorno/configuración y nunca contener una contraseña real versionada en Git.

## Smoke test obligatorio

Antes de aceptar el build en CI/local:

```sql
SELECT current_setting('server_version_num')::integer >= 180000;
SELECT uuidv4();
```

El paquete fue generado en un entorno sin servidor PostgreSQL local. Por tanto, el gate real debe ejecutar todas las migraciones desde una BD vacía **PostgreSQL 18** y luego ejecutar `database/tests/T*.sql`.

## Reglas de arquitectura

- Spring Boot demarca la transacción.
- Las Procedures no ejecutan `COMMIT`/`ROLLBACK`.
- Java consume la Database API; no realiza SQL de negocio contra tablas.
- Dinero en Java: `java.math.BigDecimal`.
- El simulador de pago es determinista: `APPROVED` / `REJECTED`.
- No se requieren extensiones PostgreSQL.
- JSONB se usa solo en parámetros/resultados transitorios, no como almacenamiento del dominio.

## Tests

Los tests funcionales abren transacciones y hacen `ROLLBACK` para no dejar fixtures.

Los escenarios concurrentes requieren dos sesiones y están documentados en `database/tests/concurrency/`.
