# PLIEGO — Flyway SQL v1.0

Executable implementation of the PLIEGO baselines for **PostgreSQL 18.x**.

## Applying migrations

Flyway must apply `database/migration/V001...V019` in order to an empty database.

`V010__seed_initial_admin.sql` requires the following placeholders:

- `PLIEGO_ADMIN_EMAIL`
- `PLIEGO_ADMIN_PASSWORD_HASH`

Their values must come from the environment/configuration and must never contain a real password committed to Git.

## Required smoke test

Before accepting the build in CI or locally:

```sql
SELECT current_setting('server_version_num')::integer >= 180000;
SELECT uuidv4();
```

The package was generated in an environment without a local PostgreSQL server. Therefore, the actual gate must execute all migrations against an empty **PostgreSQL 18** database and then run `database/tests/T*.sql`.

## Architecture rules

- Spring Boot defines the transaction boundary.
- Procedures do not execute `COMMIT`/`ROLLBACK`.
- Java consumes the Database API; it does not execute business SQL against tables.
- Money in Java: `java.math.BigDecimal`.
- The payment simulator is deterministic: `APPROVED` / `REJECTED`.
- No PostgreSQL extensions are required.
- JSONB is used only in transient parameters/results, not for domain storage.

## Tests

Functional tests open transactions and execute `ROLLBACK` to avoid leaving fixtures behind.

Concurrent scenarios require two sessions and are documented in `database/tests/concurrency/`.
