BEGIN;

DO $$
DECLARE
    v_admin BIGINT;
    v_author BIGINT; v_pub BIGINT; v_cat BIGINT; v_book BIGINT; v_ed BIGINT;
    v_mov BIGINT; v_before INTEGER; v_after INTEGER;
    v_user BIGINT; v_customer BIGINT; v_user_state VARCHAR;
    v_address BIGINT; v_cart BIGINT; v_item BIGINT; v_qty INTEGER;
    v_order BIGINT; v_order_state VARCHAR; v_pay_state VARCHAR; v_total NUMERIC; v_ref VARCHAR;
    v_cart2 BIGINT; v_item2 BIGINT; v_qty2 INTEGER;
    v_order2 BIGINT; v_order_state2 VARCHAR; v_pay_state2 VARCHAR; v_total2 NUMERIC; v_ref2 VARCHAR;
BEGIN
    INSERT INTO pliego.usuario(email_normalizado,password_hash,rol,estado)
    VALUES ('t005-admin@pliego.local','hash','ADMIN','ACTIVE')
    RETURNING usuario_id INTO v_admin;

    CALL pliego.sp_author_create(v_admin,'Autor Checkout',NULL,v_author);
    CALL pliego.sp_publisher_create(v_admin,'Editorial Checkout',NULL,v_pub);
    CALL pliego.sp_category_create(v_admin,'Checkout Cat','checkout-cat',NULL,NULL,v_cat);
    CALL pliego.sp_book_create(
        v_admin,'Libro Checkout',NULL,NULL,
        jsonb_build_array(jsonb_build_object('authorId',v_author,'order',1)),
        jsonb_build_array(v_cat),v_book
    );
    CALL pliego.sp_edition_create(
        v_admin,v_book,v_pub,'CHK-001','9780306406157','es','PAPERBACK',100,NULL,15.50,
        NULL,NULL,NULL,NULL,v_ed
    );
    CALL pliego.sp_inventory_entry(v_admin,v_ed,5,'fixture',v_mov,v_before,v_after);

    CALL pliego.sp_customer_register(
        't005-customer@pliego.local','hash','Checkout','Cliente',NULL,
        v_user,v_customer,v_user_state
    );
    CALL pliego.sp_address_create(
        v_user,'Casa','Checkout Cliente','Calle 2',NULL,'Quito','Pichincha','EC',
        NULL,'Ref','+59325550134',TRUE,v_address
    );

    CALL pliego.sp_cart_add_item(v_user,v_ed,2,v_cart,v_item,v_qty);
    CALL pliego.sp_checkout(
        v_user,v_address,'CARD','APPROVED',
        v_order,v_order_state,v_pay_state,v_total,v_ref
    );

    IF v_order_state <> 'CONFIRMED' OR v_pay_state <> 'APPROVED'
       OR v_ref IS NULL OR v_ref !~ '^SIM-[0-9a-f-]{36}$' THEN
        RAISE EXCEPTION 'approved checkout result invalid';
    END IF;
    IF (SELECT stock_actual FROM pliego.inventario WHERE edicion_id=v_ed) <> 3 THEN
        RAISE EXCEPTION 'approved checkout stock invalid';
    END IF;
    IF (SELECT count(*) FROM pliego.pedido_estado_historial WHERE pedido_id=v_order) <> 2 THEN
        RAISE EXCEPTION 'checkout must persist exactly two histories';
    END IF;
    IF (SELECT count(*) FROM pliego.movimiento_inventario WHERE pedido_id=v_order AND tipo='SALE') <> 1 THEN
        RAISE EXCEPTION 'approved checkout must produce one SALE';
    END IF;

    CALL pliego.sp_cart_add_item(v_user,v_ed,1,v_cart2,v_item2,v_qty2);
    CALL pliego.sp_checkout(
        v_user,v_address,'TRANSFER','REJECTED',
        v_order2,v_order_state2,v_pay_state2,v_total2,v_ref2
    );

    IF v_order_state2 <> 'CANCELLED' OR v_pay_state2 <> 'REJECTED' OR v_ref2 IS NOT NULL THEN
        RAISE EXCEPTION 'rejected checkout result invalid';
    END IF;
    IF (SELECT stock_actual FROM pliego.inventario WHERE edicion_id=v_ed) <> 3 THEN
        RAISE EXCEPTION 'rejected checkout must not change stock';
    END IF;
    IF (SELECT count(*) FROM pliego.movimiento_inventario WHERE pedido_id=v_order2 AND tipo='SALE') <> 0 THEN
        RAISE EXCEPTION 'rejected checkout must not produce SALE';
    END IF;
    IF (SELECT estado FROM pliego.carrito WHERE carrito_id=v_cart2) <> 'ACTIVE' THEN
        RAISE EXCEPTION 'rejected checkout must keep cart active';
    END IF;
END;
$$;

ROLLBACK;
