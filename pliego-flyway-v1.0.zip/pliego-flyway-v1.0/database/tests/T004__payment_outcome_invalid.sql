BEGIN;

DO $$
DECLARE
    v_admin BIGINT;
    v_author BIGINT; v_pub BIGINT; v_cat BIGINT; v_book BIGINT; v_ed BIGINT;
    v_mov BIGINT; v_before INTEGER; v_after INTEGER;
    v_user BIGINT; v_customer BIGINT; v_user_state VARCHAR;
    v_address BIGINT; v_cart BIGINT; v_item BIGINT; v_qty INTEGER;
    v_order BIGINT; v_order_state VARCHAR; v_pay_state VARCHAR; v_total NUMERIC; v_ref VARCHAR;
    v_sqlstate TEXT;
BEGIN
    INSERT INTO pliego.usuario(email_normalizado,password_hash,rol,estado)
    VALUES ('t004-admin@pliego.local','hash','ADMIN','ACTIVE')
    RETURNING usuario_id INTO v_admin;

    CALL pliego.sp_author_create(v_admin,'Autor Pago',NULL,v_author);
    CALL pliego.sp_publisher_create(v_admin,'Editorial Pago',NULL,v_pub);
    CALL pliego.sp_category_create(v_admin,'Literatura Pago','literatura-pago',NULL,NULL,v_cat);
    CALL pliego.sp_book_create(
        v_admin,'Libro Pago',NULL,NULL,
        jsonb_build_array(jsonb_build_object('authorId',v_author,'order',1)),
        jsonb_build_array(v_cat),v_book
    );
    CALL pliego.sp_edition_create(
        v_admin,v_book,v_pub,'PAY-001','9780306406157','es','PAPERBACK',100,NULL,10.00,
        NULL,NULL,NULL,NULL,v_ed
    );
    CALL pliego.sp_inventory_entry(v_admin,v_ed,2,'fixture',v_mov,v_before,v_after);

    CALL pliego.sp_customer_register(
        't004-customer@pliego.local','hash','Pago','Cliente',NULL,
        v_user,v_customer,v_user_state
    );
    CALL pliego.sp_address_create(
        v_user,'Casa','Pago Cliente','Calle 1',NULL,'Quito','Pichincha','EC',
        NULL,NULL,'+59325550134',TRUE,v_address
    );
    CALL pliego.sp_cart_add_item(v_user,v_ed,1,v_cart,v_item,v_qty);

    BEGIN
        CALL pliego.sp_checkout(
            v_user,v_address,'CARD','UNKNOWN',
            v_order,v_order_state,v_pay_state,v_total,v_ref
        );
        RAISE EXCEPTION 'Expected P5005';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_sqlstate = RETURNED_SQLSTATE;
        IF v_sqlstate <> 'P5005' THEN
            RAISE EXCEPTION 'Expected P5005, got %', v_sqlstate;
        END IF;
    END;
END;
$$;

ROLLBACK;
