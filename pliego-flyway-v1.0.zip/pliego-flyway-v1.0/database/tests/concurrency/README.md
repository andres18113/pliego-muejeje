# PLIEGO concurrency tests

These tests require **two psql sessions** connected to the same PostgreSQL 18 test database.

## C1 — Last-unit checkout

Prepare two ACTIVE customers, each with an ACTIVE cart containing quantity 1 of the same edition; set `stock_actual = 1` through public inventory procedures.

- Session A: `BEGIN; CALL pliego.sp_checkout(..., 'APPROVED', ...);` and pause before `COMMIT`.
- Session B: `BEGIN; CALL pliego.sp_checkout(..., 'APPROVED', ...);`.
- Session B must block on the inventory row.
- Commit A.
- B must resume and fail with `P3002 INSUFFICIENT_STOCK` (or the symmetric result if B wins first).

Postconditions:

- exactly one new Pedido is `CONFIRMED`;
- exactly one SALE exists for the winning Pedido/Edicion;
- final `stock_actual = 0`;
- stock never becomes negative.

## C2 — Double cancellation

Prepare one `CONFIRMED` order with `APPROVED` payment and its SALE.

- Session A begins and calls `sp_order_cancel`; pause before commit.
- Session B calls `sp_order_cancel` for the same order and blocks on Pedido.
- Commit A.
- B must resume and fail because the order is no longer cancellable.

Postconditions:

- one CANCELLATION per Pedido/Edicion;
- stock restored exactly once;
- Pago `REFUNDED`;
- Pedido `CANCELLED`.
