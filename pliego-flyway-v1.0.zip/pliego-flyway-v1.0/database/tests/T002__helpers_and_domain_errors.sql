BEGIN;

DO $$
DECLARE
    v_uid BIGINT;
    v_cid BIGINT;
    v_state VARCHAR;
    v_sqlstate TEXT;
BEGIN
    IF NOT pliego.fn_is_valid_country_code('EC') THEN
        RAISE EXCEPTION 'EC must be valid';
    END IF;
    IF pliego.fn_is_valid_country_code('ZZ') THEN
        RAISE EXCEPTION 'ZZ must be invalid';
    END IF;
    IF pliego.fn_normalize_country_code(' ecu ') <> 'ECU' THEN
        RAISE EXCEPTION 'country normalizer must not truncate';
    END IF;
    IF NOT pliego.fn_is_valid_isbn13('9780306406157') THEN
        RAISE EXCEPTION 'valid ISBN rejected';
    END IF;
    IF pliego.fn_is_valid_isbn13('9780306406158') THEN
        RAISE EXCEPTION 'invalid ISBN accepted';
    END IF;
    IF pliego.fn_generate_payment_reference() !~ '^SIM-[0-9a-f-]{36}$' THEN
        RAISE EXCEPTION 'SIM UUID reference format invalid';
    END IF;

    -- RC-03: public routines must not leak raw CHECK SQLSTATE for reachable invalid input.
    BEGIN
        CALL pliego.sp_customer_register(
            'bad-email', 'hash', 'A', 'B', NULL,
            v_uid, v_cid, v_state
        );
        RAISE EXCEPTION 'Expected a domain SQLSTATE';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_sqlstate = RETURNED_SQLSTATE;
        IF v_sqlstate NOT LIKE 'P____' THEN
            RAISE EXCEPTION 'Expected domain SQLSTATE P____, got %', v_sqlstate;
        END IF;
    END;
END;
$$;

ROLLBACK;
