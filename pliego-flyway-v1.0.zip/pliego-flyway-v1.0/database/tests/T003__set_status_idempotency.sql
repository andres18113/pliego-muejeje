BEGIN;

DO $$
DECLARE
    v_admin BIGINT;
    v_author BIGINT;
BEGIN
    INSERT INTO pliego.usuario(email_normalizado,password_hash,rol,estado)
    VALUES ('t003-admin@pliego.local','hash','ADMIN','ACTIVE')
    RETURNING usuario_id INTO v_admin;

    CALL pliego.sp_author_create(v_admin, 'Autor Test', NULL, v_author);
    CALL pliego.sp_author_set_status(v_admin, v_author, 'ACTIVE');
    CALL pliego.sp_author_set_status(v_admin, v_author, 'ACTIVE');

    IF (SELECT estado FROM pliego.autor WHERE autor_id = v_author) <> 'ACTIVE' THEN
        RAISE EXCEPTION 'same-state set_status failed';
    END IF;
END;
$$;

ROLLBACK;
