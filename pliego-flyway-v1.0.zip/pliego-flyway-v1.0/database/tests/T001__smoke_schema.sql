-- PLIEGO T001 — Structural smoke
DO $$
DECLARE
    v_tables INTEGER;
    v_public_routines INTEGER;
    v_triggers INTEGER;
BEGIN
    IF current_setting('server_version_num')::INTEGER < 180000 THEN
        RAISE EXCEPTION 'PostgreSQL 18+ required';
    END IF;

    PERFORM uuidv4();

    SELECT count(*) INTO v_tables
      FROM information_schema.tables
     WHERE table_schema = 'pliego'
       AND table_type = 'BASE TABLE';
    IF v_tables <> 19 THEN
        RAISE EXCEPTION 'Expected 19 PLIEGO tables, got %', v_tables;
    END IF;

    SELECT count(*) INTO v_public_routines
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
     WHERE n.nspname = 'pliego'
       AND p.proname IN (
        'sp_customer_register','fn_user_auth_data','fn_admin_customer_search','sp_customer_set_status',
        'fn_customer_profile','sp_customer_update','fn_address_list','sp_address_create',
        'sp_address_update','sp_address_delete','sp_address_set_primary',
        'fn_catalog_search','fn_edition_detail','fn_admin_author_search','fn_admin_publisher_search',
        'fn_admin_category_search','fn_admin_book_search','fn_admin_edition_search',
        'sp_author_create','sp_author_update','sp_author_set_status',
        'sp_publisher_create','sp_publisher_update','sp_publisher_set_status',
        'sp_category_create','sp_category_update','sp_category_set_status',
        'sp_book_create','sp_book_update','sp_book_set_status',
        'sp_edition_create','sp_edition_update','sp_edition_set_status',
        'fn_inventory_search','fn_inventory_movements','sp_inventory_entry','sp_inventory_adjust',
        'sp_inventory_set_minimum','fn_cart_get','sp_cart_add_item','sp_cart_update_item',
        'sp_cart_remove_item','sp_checkout','fn_customer_orders','fn_customer_order_detail',
        'sp_order_cancel','fn_admin_orders','fn_admin_order_detail','sp_order_change_status'
       );
    IF v_public_routines <> 49 THEN
        RAISE EXCEPTION 'Expected 49 public routines, got %', v_public_routines;
    END IF;

    SELECT count(*) INTO v_triggers
      FROM pg_trigger t
      JOIN pg_class c ON c.oid = t.tgrelid
      JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = 'pliego'
       AND NOT t.tgisinternal;
    IF v_triggers <> 18 THEN
        RAISE EXCEPTION 'Expected 18 PLIEGO triggers, got %', v_triggers;
    END IF;
END;
$$;
