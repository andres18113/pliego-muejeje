BEGIN;

-- Physical-capacity test: aggregate values exceed NUMERIC(14,2), but fit NUMERIC(30,2).
DO $$
DECLARE
    v_user BIGINT;
    v_customer BIGINT;
    v_author BIGINT;
    v_pub BIGINT;
    v_cat BIGINT;
    v_book BIGINT;
    v_ed BIGINT;
    v_order BIGINT;
BEGIN
    INSERT INTO pliego.usuario(email_normalizado,password_hash,rol,estado)
    VALUES('t007-money@pliego.local','hash','CUSTOMER','ACTIVE')
    RETURNING usuario_id INTO v_user;

    INSERT INTO pliego.cliente(usuario_id,nombres,apellidos)
    VALUES(v_user,'Money','Capacity')
    RETURNING cliente_id INTO v_customer;

    INSERT INTO pliego.autor(nombre) VALUES('Money Author') RETURNING autor_id INTO v_author;
    INSERT INTO pliego.editorial(nombre) VALUES('Money Publisher') RETURNING editorial_id INTO v_pub;
    INSERT INTO pliego.categoria(nombre,slug) VALUES('Money Category','money-category') RETURNING categoria_id INTO v_cat;
    INSERT INTO pliego.libro(titulo) VALUES('Money Book') RETURNING libro_id INTO v_book;
    INSERT INTO pliego.libro_autor(libro_id,autor_id,orden_autoria) VALUES(v_book,v_author,1);
    INSERT INTO pliego.libro_categoria(libro_id,categoria_id) VALUES(v_book,v_cat);
    INSERT INTO pliego.edicion(libro_id,editorial_id,sku,idioma,formato,numero_paginas,precio)
    VALUES(v_book,v_pub,'MONEY-001','es','PAPERBACK',1,999999999.99)
    RETURNING edicion_id INTO v_ed;
    INSERT INTO pliego.inventario(edicion_id) VALUES(v_ed);

    INSERT INTO pliego.pedido(cliente_id,estado,subtotal,total)
    VALUES(v_customer,'PENDING_PAYMENT',2147483646978525163.53,2147483646978525163.53)
    RETURNING pedido_id INTO v_order;

    INSERT INTO pliego.pedido_item(
        pedido_id,edicion_id,sku_snapshot,titulo_snapshot,autores_snapshot,
        editorial_snapshot,formato_snapshot,idioma_snapshot,
        precio_unitario,cantidad,subtotal
    ) VALUES(
        v_order,v_ed,'MONEY-001','Money Book','Money Author','Money Publisher',
        'PAPERBACK','es',999999999.99,2147483647,2147483646978525163.53
    );

    IF (SELECT subtotal FROM pliego.pedido_item WHERE pedido_id=v_order)
       <> 2147483646978525163.53::NUMERIC(30,2) THEN
        RAISE EXCEPTION 'NUMERIC(30,2) capacity test failed';
    END IF;
END;
$$;

ROLLBACK;
