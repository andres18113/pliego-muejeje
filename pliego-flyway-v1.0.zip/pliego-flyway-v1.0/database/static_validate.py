from pathlib import Path
import re

base = Path(__file__).parent / 'migration'
files = sorted(base.glob('V*.sql'))
assert len(files) == 19, f'Expected 19 migrations, got {len(files)}'
text = '\n'.join(p.read_text(encoding='utf-8') for p in files)

tables = re.findall(r'\bCREATE TABLE\s+pliego\.([a-z0-9_]+)', text, re.I)
assert len(tables) == 19 and len(set(tables)) == 19, (len(tables), len(set(tables)))

procedures = re.findall(r'CREATE OR REPLACE PROCEDURE\s+pliego\.([a-z0-9_]+)', text, re.I)
functions = re.findall(r'CREATE OR REPLACE FUNCTION\s+pliego\.([a-z0-9_]+)', text, re.I)
triggers = re.findall(r'\bCREATE TRIGGER\s+([a-z0-9_]+)', text, re.I)
assert len(procedures) == 31, len(procedures)
assert len(functions) == 35, len(functions)  # 18 public + 14 helpers + 3 trigger functions
assert len(triggers) == 18, len(triggers)

expected_public = {
'sp_customer_register','fn_user_auth_data','fn_admin_customer_search','sp_customer_set_status',
'fn_customer_profile','sp_customer_update','fn_address_list','sp_address_create','sp_address_update','sp_address_delete','sp_address_set_primary',
'fn_catalog_search','fn_edition_detail','fn_admin_author_search','fn_admin_publisher_search','fn_admin_category_search','fn_admin_book_search','fn_admin_edition_search',
'sp_author_create','sp_author_update','sp_author_set_status','sp_publisher_create','sp_publisher_update','sp_publisher_set_status','sp_category_create','sp_category_update','sp_category_set_status','sp_book_create','sp_book_update','sp_book_set_status','sp_edition_create','sp_edition_update','sp_edition_set_status',
'fn_inventory_search','fn_inventory_movements','sp_inventory_entry','sp_inventory_adjust','sp_inventory_set_minimum',
'fn_cart_get','sp_cart_add_item','sp_cart_update_item','sp_cart_remove_item',
'sp_checkout','fn_customer_orders','fn_customer_order_detail','sp_order_cancel','fn_admin_orders','fn_admin_order_detail','sp_order_change_status'
}
created = set(procedures) | set(functions)
assert not (expected_public-created), sorted(expected_public-created)

for p in files:
    t = p.read_text(encoding='utf-8')
    assert t.count('$$') % 2 == 0, f'Unbalanced dollar quote in {p.name}'

assert 'uuidv4()' in text
assert 'SECURITY DEFINER' not in text.upper()
assert 'CREATE EXTENSION' not in text.upper()
assert 'COMMIT;' not in text.upper() and 'ROLLBACK;' not in text.upper()
assert len(re.findall(r'SECURITY INVOKER', text, re.I)) == len(procedures) + len(functions)
assert 'NUMERIC(14,2)' not in text.upper()
assert "NUMERIC(30,2)" in text
assert "RETURNS TEXT LANGUAGE sql IMMUTABLE STRICT SECURITY INVOKER AS $$ SELECT upper(btrim(p_value)); $$;" in text
assert "'P9001'" in text
assert "FOR SHARE OF e, l" in text

print('STATIC VALIDATION PASS')
print('migrations=', len(files))
print('tables=', len(tables))
print('procedures=', len(procedures))
print('functions_total=', len(functions))
print('public_routines=', len(expected_public))
# All explicitly qualified helper calls must exist.
helper_calls=set(re.findall(r'pliego\.(fn_[a-z0-9_]+)\s*\(', text, re.I))
created_functions=set(functions)
missing_helpers=helper_calls-created_functions
assert not missing_helpers, sorted(missing_helpers)

print('triggers=', len(triggers))
print('security_invoker=', len(re.findall(r'SECURITY INVOKER', text, re.I)))
print('helper_references_resolved=', len(helper_calls))
