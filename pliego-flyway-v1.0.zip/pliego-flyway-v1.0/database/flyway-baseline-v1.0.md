# PLIEGO — Flyway Baseline v1.0

**Documento:** FLY-PLIEGO-001  
**Versión:** 1.0  
**Estado:** BASELINE APROBADA  
**Fecha:** 2026-09-23  
**Proyecto:** PLIEGO  
**Tipo:** Materialización SQL ejecutable de las baselines aprobadas

## 1. Fuentes

Esta baseline materializa exclusivamente:

- UCB v1.1 — BASELINE;
- DER v1.1 — BASELINE;
- Diccionario de Datos v1.1 — BASELINE;
- Database API Contract v1.1 — BASELINE;
- Modelo Físico PostgreSQL v1.0 — BASELINE;
- Catálogo de Rutinas v1.0 — BASELINE.

No incorpora requisitos de negocio nuevos.

## 2. Motor

- PostgreSQL 18.x.
- Schema: `pliego`.
- Flyway versioned migrations.
- Sin Docker.
- Sin extensiones PostgreSQL.

## 3. Migraciones

| Migración | Responsabilidad |
|---|---|
| V001 | Schema `pliego` |
| V002 | Usuario, Cliente, Dirección |
| V003 | Catálogo |
| V004 | Inventario actual |
| V005 | Carrito |
| V006 | Pedido, snapshots, Pago, historial |
| V007 | Movimiento de inventario |
| V008 | Índices |
| V009 | Helper único de país + constraints ISO |
| V010 | Seed ADMIN por placeholders de entorno |
| V011 | Helpers internos |
| V012 | Identity/Customer Database API |
| V013 | Functions de consulta de catálogo |
| V014 | Comandos administrativos de catálogo |
| V015 | Database API de inventario |
| V016 | Database API de carrito |
| V017 | Checkout/Pedidos |
| V018 | Trigger-functions técnicas |
| V019 | 18 triggers técnicos |

## 4. Conteos verificados estáticamente

```text
Migraciones             19
CREATE TABLE            19
Procedures públicas     31
Functions públicas      18
Rutinas públicas total  49
Helpers internos        14
Trigger-functions        3
Functions total         35
Triggers                 18
SECURITY INVOKER         66
```

Además:

- 0 `SECURITY DEFINER`;
- 0 `CREATE EXTENSION`;
- 0 `COMMIT` / `ROLLBACK` dentro de migraciones;
- 0 `NUMERIC(14,2)` residual;
- todos los helpers `pliego.fn_*` referenciados existen;
- `uuidv4()` está reservado al PostgreSQL 18 objetivo.

## 5. Tests incluidos

- T001 — estructura y conteos;
- T002 — helpers + contrato SQLSTATE;
- T003 — `set_status` same-state idempotente;
- T004 — payment outcome inválido → `P5005`;
- T005 — checkout APPROVED/REJECTED;
- T006 — cancelación + append-only → `P9001`;
- T007 — capacidad `NUMERIC(30,2)`.

Los tests funcionales hacen `ROLLBACK`.

## 6. Concurrencia

Los casos de:

- última unidad entre dos checkouts;
- doble cancelación;

requieren dos sesiones PostgreSQL y están documentados en `tests/concurrency/README.md`.

## 7. Gate de aceptación

Esta baseline solo pasa de **CANDIDATO** a **BASELINE APROBADA** cuando en PostgreSQL 18 real se verifique:

1. `flyway migrate` desde una BD vacía;
2. `flyway validate`;
3. `SELECT uuidv4()`;
4. T001–T007 sin errores;
5. concurrencia C1/C2;
6. una segunda creación de BD desde cero produce el mismo estado final;
7. no existen objetos fuera del schema/contrato esperado.

## 8. Limitación de esta entrega

Smoke PostgreSQL 18.6 verificado el 2026-09-23: `flyway migrate` 19/19 desde BD vacía, `flyway validate` 19/19, `uuidv4()` nativo, T001–T007 PASS, C1 (P3002 + postcondiciones), C2 (P5003 + postcondiciones), segunda BD con schema idéntico, inventario 19 tablas / 31 procedures / 18 triggers sin objetos extra.

## 9. Próxima etapa

Tras aprobar el smoke PostgreSQL 18:

```text
Flyway Baseline v1.0
        ↓
REST API Contract v1.0
        ↓
Spring JDBC Gateways
        ↓
Controllers / Services
        ↓
Integración y pruebas
```
