# PLIEGO — Flyway Baseline v1.0

**Document:** FLY-PLIEGO-001  
**Version:** 1.0  
**Status:** APPROVED BASELINE  
**Date:** 2026-09-23  
**Project:** PLIEGO  
**Type:** Executable SQL implementation of the approved baselines

## 1. Sources

This baseline implements only:

- UCB v1.1 — BASELINE;
- Logical ERD v1.1 — BASELINE;
- Data Dictionary v1.1 — BASELINE;
- Database API Contract v1.1 — BASELINE;
- PostgreSQL Physical Model v1.0 — BASELINE;
- Routine Catalog v1.0 — BASELINE.

It introduces no new business requirements.

## 2. Database engine

- PostgreSQL 18.x.
- Schema: `pliego`.
- Flyway versioned migrations.
- No Docker.
- No PostgreSQL extensions.

## 3. Migrations

| Migration | Responsibility |
|---|---|
| V001 | Schema `pliego` |
| V002 | Usuario, Cliente, Dirección |
| V003 | Catalog |
| V004 | Current inventory |
| V005 | Cart |
| V006 | Pedido, snapshots, Pago, history |
| V007 | Inventory movement |
| V008 | Indexes |
| V009 | Single country helper + ISO constraints |
| V010 | ADMIN seed through environment placeholders |
| V011 | Internal helpers |
| V012 | Identity/Customer Database API |
| V013 | Catalog query functions |
| V014 | Catalog administration commands |
| V015 | Inventory Database API |
| V016 | Cart Database API |
| V017 | Checkout/Orders |
| V018 | Technical trigger functions |
| V019 | 18 technical triggers |

## 4. Statically verified counts

```text
Migrations              19
CREATE TABLE            19
Public procedures       31
Public functions        18
Total public routines   49
Internal helpers        14
Trigger functions        3
Total functions         35
Triggers                18
SECURITY INVOKER         66
```

In addition:

- 0 `SECURITY DEFINER`;
- 0 `CREATE EXTENSION`;
- 0 `COMMIT` / `ROLLBACK` inside migrations;
- 0 residual `NUMERIC(14,2)`;
- all referenced `pliego.fn_*` helpers exist;
- `uuidv4()` is reserved for the PostgreSQL 18 target.

## 5. Included tests

- T001 — structure and counts;
- T002 — helpers + SQLSTATE contract;
- T003 — same-state idempotency for `set_status`;
- T004 — invalid payment outcome → `P5005`;
- T005 — APPROVED/REJECTED checkout;
- T006 — cancellation + append-only → `P9001`;
- T007 — `NUMERIC(30,2)` capacity.

Functional tests execute `ROLLBACK`.

## 6. Concurrency

The following cases:

- the last unit contested by two checkouts;
- double cancellation;

require two PostgreSQL sessions and are documented in `tests/concurrency/README.md`.

## 7. Acceptance gate

This baseline moves from **CANDIDATE** to **APPROVED BASELINE** only after the following are verified on an actual PostgreSQL 18 instance:

1. `flyway migrate` from an empty database;
2. `flyway validate`;
3. `SELECT uuidv4()`;
4. T001–T007 without errors;
5. C1/C2 concurrency;
6. a second database created from scratch produces the same final state;
7. no objects exist outside the expected schema/contract.

## 8. Delivery limitation

PostgreSQL 18.6 smoke test verified on 2026-09-23: `flyway migrate` 19/19 from an empty database, `flyway validate` 19/19, native `uuidv4()`, T001–T007 PASS, C1 (P3002 + postconditions), C2 (P5003 + postconditions), a second database with an identical schema, inventory of 19 tables / 31 procedures / 18 triggers with no extra objects.

## 9. Next stage

After approving the PostgreSQL 18 smoke test:

```text
Flyway Baseline v1.0
        ↓
REST API Contract v1.0
        ↓
Spring JDBC Gateways
        ↓
Controllers / Services
        ↓
Integration and testing
```
